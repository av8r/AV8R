#!/usr/bin/env python
"""
This script is equivalent to the following:
FLASK_APP=wsgi.py FLASK_DEBUG=true flask

(By default, always runs with FLASK_DEBUG=true, unless --env=prod is passed or
FLASK_DEBUG is set to false, no or 0)

USAGE:
python manage.py [--env=prod] [--no-warn] COMMAND [OPTIONS] [ARGS]
"""
import argparse
import os
import sys
import click
import time

from flask.cli import FlaskGroup, run_command
from app import create_app, create_dash
import app.commands


def production_warning(env, args):
    if len(args):
        env = 'PRODUCTION' if env == 'prod' else 'STAGING'
        cmd = ' '.join(args)
        # allow some time to cancel commands
        for i in [4, 3, 2, 1]:
            click.echo(f'!! {env} !!: Running "{cmd}" in {i} seconds')
            time.sleep(1)


@click.group(cls=FlaskGroup,
             add_default_commands=True,
             # create_app=lambda _: init_app(),
             create_app=lambda: create_app(create_dash).server,
             help="""\
A utility script for the Flask Dash application.
""")
@click.option('-p', '--port', type=click.IntRange(min=1080, max=9999), default=5000,
              help='Bind on port (default 5000)')
@click.option('-E', '--env', type=click.Choice(['dev', 'prod']), default='dev',
              help='Whether to use DevConfig or ProdConfig (dev by default).')
@click.option('--warn/--no-warn', default=True,
              help='Whether or not to warn if running in production.')
@click.option('-v', '--verbose', type=click.IntRange(min=0, max=5), default=5,
              help='Verbose level [0: None, 5: Debug] (default: 5)')
@click.option('-l', '--logfile', type=click.STRING, default=None,
              help='log to filename (default: None)')
@click.option('-m', '--modin', type=click.Choice(['dask', 'ray', 'python', 'debug', '']), default='',
              help='modin engine to use [dask, ray, python, debug]. (default: None)')
@click.pass_context
def cli(ctx, port, env, warn, verbose, logfile, modin):
    ctx.obj.data['env'] = env
    ctx.obj.data['verbose'] = verbose

    if port:
        os.environ['FLASK_RUN_PORT'] = str(port)

    if env != 'dev' and warn:
        production_warning(env, sys.argv[2:])

    # logging level
    # setup_logging(verbose, logfile, env, sys.argv[1:])

    # modin engine
    os.environ['MODIN_ENGINE'] = modin


def main():
    parser = argparse.ArgumentParser(add_help=False)        # use Click help
    parser.add_argument('--port', default='5000')
    parser.add_argument('--env', default='dev')
    args, _ = parser.parse_known_args()

    if args.env == 'dev':
        os.environ['FLASK_DEBUG'] = 'true'

    cli.add_command(run_command)
    # from app.commands
    cli.add_command(app.commands.cli_run_wsgi)
    cli.add_command(app.commands.cli_create_database)
    cli.add_command(app.commands.cli_create_admin)
    cli.add_command(app.commands.cli_load_data)
    cli.add_command(app.commands.cli_sphinxdoc_build)
    # Main
    cli.main(args=sys.argv[1:])

    # ## TODO socketio ?
    # if socketio:
    #     socketio.run(app, ='0.0.0.0', port=app.config['PORT'])
    # else:
    #     app.run(host='0.0.0.0', port=app.cnfig['PORT'], threadded=True, processes=1)


if __name__ == '__main__':
    main()
