

https://pydata-sphinx-theme.readthedocs.io/en/stable/index.html


# import dash_sphinx.sphinx_ext.jsontoc
# getattr(sys.modules[__name__], attr)


--
TODO:
=====

DB:
---

- db.create : app.__init__ / dash_spa_admin.login_manager
    ==> try / except : not 100% Ok (windows path if sqlite driver)

SPHINX:
-------
- SPHINX_DOC_ROOT (__init__.py) - via conf
- global opt (.ini):
  - pdflatex, author, ...
  - available builders 
  ==>overwrite by prj_doc conf
- prj_doc conf:
  - enable / disable
  - auth required
- sphinx.tools.py / api ? ==> un hardcode default api 
  
ADD Page (register):
--------------------
app.pages.default_container
==> register_page

Add Menu Item
-------------
- Sign In:
  - dash_spa_admin.admin_nav_bar
- Nav Bar:
  - app.pages.__init__ + app.pages.default_container



XXX
---
dash_spa.dash_spa_pages:
  - add_external_scripts
  - add_external_stylesheets

config_section = -[(k, v) for k; v in config.config.sections.item() if k.startswith('sphinx.')]