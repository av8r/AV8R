========
Contents
========

These sections show off various features and styles of this theme.
They should help you understand how this theme behaves and how others are using it.
See the sections in the primary sidebar and below to explore.

.. toctree::
    :caption: Example 1
    :glob:

    example_01/*


.. toctree::
    :maxdepth: 2
    :caption: Example 2
    :glob:


    example_02/*