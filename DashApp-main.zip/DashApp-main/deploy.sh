#!/bin/bash
set -e
PYTHON=python3    # .11
VENV=.venv

if [ -d "${VENV}" -a -f "${VENV}/bin/activate" ]; then
  echo "Update"
else
  echo "Install"
  sudo apt install python3-venv
  (${PYTHON} -m venv ${VENV}  || virtualenv -p "$(command -v ${PYTHON})" ${VENV}) 2>/dev/null
  [ $? -ne 0 ] && echo "Cannot create virtualenv" && exit 1
fi

source ${VENV}/bin/activate
${VENV}/bin/${PYTHON} -m pip install --upgrade pip wheel setuptools virtualenv
deactivate && source ${VENV}/bin/activate
${VENV}/bin/${PYTHON} -m pip install --upgrade cpython
${VENV}/bin/${PYTHON} -m pip install --upgrade -r requirements.txt
