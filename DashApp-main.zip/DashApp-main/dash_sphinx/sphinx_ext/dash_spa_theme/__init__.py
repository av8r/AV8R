# -*- coding: utf-8 -*-

from pathlib import Path
from sphinx.application import Sphinx


def setup(app:Sphinx):
    """ Setup the Shinx application."""
    here = Path(__file__).parent.resolve()
    theme_path = here / "theme"
    app.add_html_theme("dash_spa_theme", str(theme_path))

    # Events
    # app.connect()

    return {
        "parallel_read_safe": True,
        "parallel_write_safe": True,
    }
