__version__ = '0.0.1'
__author__ = 'Stephane ENGEL <stephane.engel@Macchiati.org>'
__all__ = []
