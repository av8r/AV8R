# -*- coding: utf-8 -*-

from dash import html   # , dcc, ctx
import dash_bootstrap_components as dbc
from dash_spa import config
from dash_spa.components import NavbarDropdown
from dash_sphinx import SPHINX_DOC_ROUTE, SPHINX_INI_PREFIX, SPHINX_DOC_TITLE


# from dash_spa.logging import log


class SphinxDropDownMenu(NavbarDropdown):
    def __init__(self):
        super().__init__(
            [
                dbc.NavLink(
                    [html.I(className="fab fa-fw fa-dochub"), ' ' + prj_cfg['title']],
                    href=f'{SPHINX_DOC_ROUTE}/{prj_id.replace(SPHINX_INI_PREFIX, "")}'
                ) for prj_id, prj_cfg in config.config.sections.items()
                if prj_id.startswith(SPHINX_INI_PREFIX) and 'title' in prj_cfg
            ],
            SPHINX_DOC_TITLE
        )