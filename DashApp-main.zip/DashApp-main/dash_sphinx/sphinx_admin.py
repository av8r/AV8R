# -*- coding: utf-8 -*-
from io import StringIO
from ansi2html import Ansi2HTMLConverter
import dash_dangerously_set_inner_html


from dash import html, ctx
import dash_bootstrap_components as dbc
from dash_spa import config, callback, register_page
from dash_spa.logging import log
from sphinx.application import Sphinx
from flask_restx import Namespace
from dash.dependencies import Input, Output
import json
import os
from multiprocessing import cpu_count
from sphinx.util.docutils import docutils_namespace
from sphinx.util.console import bold, red       # type: ignore

from dash_sphinx import SPHINX_DOC_ROOT, SPHINX_INI_PREFIX

ns = Namespace('sphinxdoc_admin', description='Operations related to doc (sphinx)')

__allowed_builders__ = ['json', 'pdf', 'html']


class SphinxApp(object):
    config_name = source = conf = prj_id = None

    def __init__(self, **kwargs):
        log.debug(kwargs)
        # Setup with config_name
        if 'config_name' in kwargs:
            sphinx_opt = config.get(f"{SPHINX_INI_PREFIX}{kwargs['config_name']}")
            [setattr(self, k, v) for k, v in sphinx_opt.__dict__.items()]
        # update/init with key=value arguments
        [setattr(self, k, v) for k, v in kwargs.items()]

    def build(self, builders=None):
        log.info(f"Build ....{os.environ['DASH_SPA_CWD']}")
        rc = []
        if self.source and self.conf and builders:
            builders = builders if isinstance(builders, list) else [builders]
            # confdir = os.path.dirname(self.conf)
            os.environ['SPHINX_CONF'] = os.path.abspath(self.conf)
            confdir = os.path.dirname(os.path.abspath(__file__))
            # XXX
            prj_id = self.prj_id
            app_root = os.path.join(SPHINX_DOC_ROOT, prj_id)
            doctreedir = os.path.join(app_root, '.doctrees')

            for builder in builders:
                if builders not in __allowed_builders__:
                    outdir = app_root if builder != 'pdf' else os.path.join(app_root, 'pdf')
                    status, warning = StringIO(), StringIO()

                    if builder == 'pdf':
                        _buildername = 'latex'
                    elif builder == 'json':
                        _buildername = 'jsontoc'
                    else:
                        _buildername = builder

                    # run Sphinx in source dir
                    cwd = os.getcwd()
                    os.chdir(self.source)

                    # Avoid WARNING(s) while setting ... is already registered, it will be overridden
                    # see http://github.com/sphinx-doc/issues/5038

                    sphinx_error = False
                    with docutils_namespace():
                        try:
                            # setup Sphinx
                            sphinx = Sphinx(
                                srcdir=self.source,
                                confdir=confdir,
                                outdir=outdir,
                                doctreedir=doctreedir,
                                # buildername='latex' if builder == 'pdf' else builder,
                                # buildername='latex' if builder == 'pdf' else 'jsontoc',
                                buildername=_buildername,
                                freshenv=True,
                                parallel=cpu_count(),
                                status=status,
                                warning=warning,
                            )
                            # XXX KO : prefix base url with prj_id => multi sphinx project
                            # sphinx.config_value('html_baseurl', prj_id, True)
                            # sphinx.config['html_baseurl'] = prj_id
                            log.info(f"Building: {prj_id} with {builder}")
                            sphinx.build()
                        except Exception as e:
                            log.error(f"Building: {prj_id} with {builder} failed : {e}", stack_info=True, exc_info=True)
                            status.write(bold(red("========== Build failed =============\n")))
                            warning.write(bold("========== Build failed =============\n")
                                          + red(f"{e}\n")
                                          + "See full log for details")
                            sphinx_error = True
                    # run pdflatex until
                    if builder == 'pdf' and not sphinx_error:
                        import re
                        import subprocess

                        # move to latex output in order to run pdflatex locally
                        os.chdir(outdir)
                        for latex_document in sphinx.config.latex_documents:
                            pdflatex_logfile = latex_document[1].replace('.tex', '.log')
                            pdflatex_docpdf = latex_document[1].replace('.tex', '.pdf')
                            # _pdflatex_cmd = "pdflatex"
                            _pdflatex_cmd = getattr(self, 'pdflatex', 'pdflatex')
                            print(_pdflatex_cmd)
                            # TODO - conf
                            # if 'SPHINX_LATEX_BINDIR' in current_app.config:
                            #     _pdflatex_cmd = os.path.join(current_app.config['SPHINX_LATEX_BINDIR'], _pdflatex_cmd)
                            pdflatex_cmd = [_pdflatex_cmd,
                                            "--shell-escape",
                                            "--synctex=1",
                                            "--interaction=nonstopmode",
                                            "--draftmode",
                                            latex_document[1]
                                            ]

                            # Rerun pdflatex until needed
                            rerun = True
                            cpt = 0
                            # input("Press Enter to continue ({})".format(latex_document[1]))
                            while rerun:
                                cpt += 1
                                log.info(f"Running pdflatex - count: {cpt}")
                                rerun = False

                                # Remove "--draftmode",
                                if "--draftmode" in pdflatex_cmd:
                                    pdflatex_cmd.remove("--draftmode")
                                # Quiet pdflatex
                                with open(os.devnull, "w") as f:
                                    pdflatex_rc = subprocess.call(pdflatex_cmd, stdout=f)
                                # subprocess.call(pdflatex_cmd)
                                logfile = open(pdflatex_logfile, "r", encoding="utf8", errors="ignore")
                                for line in logfile:
                                    if re.search('may have changed', line):
                                        rerun = True
                                        break
                                if cpt > 5:
                                    log.warning("Running pdflatex - break (count > 5)")
                                    break
                                logfile.close()

                                # if pdflatex_rc > 10:
                                #     input("Press Enter to continue [{}] -> {}\n{}/{}\n".format(
                                #         pdflatex_rc, rerun, latex_outputdir, pdflatex_logfile))

                            # Update status / warning
                            if os.path.isfile(pdflatex_docpdf):
                                # status.write(f"\n>>>>> PDF: <a href='{pdflatex_docpdf}'>{pdflatex_docpdf}</a>\n")
                                status.write(f"\n>>>>> PDF: {pdflatex_docpdf}\n")
                            else:
                                warning.write(f"\n>>>>>>>> PDF: KO -- see logfile: {pdflatex_logfile}")
                            # if 'copy2' in _docroots[docroot] \
                            #         and _docroots[docroot]['copy2'] \
                            #         and os.path.isdir(_docroots[docroot]['copy2']):
                            #     # shutil.copy2(pdflatex_docpdf, '/dst/dir/newname.ext')  # complete target filename given
                            #     # shutil.copy2(pdflatex_docpdf, '/dst/dir')  # target filename is /dst/dir/file.ext
                            #     shutil.copy2(pdflatex_docpdf, _docroots[docroot]['copy2'])

                    # chdir back to CWD
                    os.chdir(cwd)
                    rc.append((builder, status.getvalue(), warning.getvalue()))
                else:
                    log.error(f"builder: {builder} not allowed")
                    rc.append((builder, 'ERROR', f"builder: {builder} not allowed"))
        else:
            log.error(f"srcdir: {self.source} / confdir: {os.path.dirname(self.conf)} / outdir: {self.outdir}"
                      f" / doctreedir: {self.doctreedir} and builders: {builders}")
            rc.append((builders.join(', '), 'ERROR (call)', f"source: {self.source} and conf: {self.conf}"))
        return rc


def layout():
    builder_value = __allowed_builders__.copy()
    sphinx_options = [
        {
            'label': prj_cfg['title'],
            'value': json.dumps({
                'prj_id': prj_id.replace(SPHINX_INI_PREFIX, ''),
                **prj_cfg
            })
        } for prj_id, prj_cfg in config.config.sections.items()
        if prj_id.startswith(SPHINX_INI_PREFIX) and 'title' in prj_cfg
    ]

    return dbc.Container([
        html.H2('Sphinx Documentation Manager'),
        html.Div([
            # dcc.Dropdown(
            dbc.Select(
                options=sphinx_options,
                id='dropdown-admin-sphinx',
                placeholder="Select a Sphinx documentation",
                # multi=True,  # dcc + https://github.com/tcbegley/dash-bootstrap-css
                className='me-md-auto'
            ),
            dbc.Label("Builder: "),
            dbc.Checklist(
                options=[
                    {"label": builder_value[0].upper(), "value": builder_value[0]},
                    {"label": builder_value[1].upper(), "value": builder_value[1]},
                    {"label": builder_value[2].upper(), "value": builder_value[2], "disabled": False},       # HTML
                ],
                value=builder_value[0:2],
                id="checklist-input-admin-sphinx",
                inline=True,
                className='me-md-6'
            ),
            dbc.Button("Build", id='btn-admin-sphinx', className='me-md-1'),
        ]),
        html.Hr(),
        html.Div(id='div-output-admin-sphinx')
    ])


@callback(
    Output('div-output-admin-sphinx', 'children'),
    [
        Input('dropdown-admin-sphinx', 'value'),
        Input('checklist-input-admin-sphinx', 'value'),
        Input('btn-admin-sphinx', 'n_clicks'),
    ],
    prevent_initial_call=True
)
def update_sphinx_admin(sphinx_cfg, sphinx_builders, btn):
    sphinx_cfg = json.loads(sphinx_cfg) if sphinx_cfg else None
    button_clicked = ctx.triggered_id

    if button_clicked == 'btn-admin-sphinx':
        if sphinx_cfg and len(sphinx_builders):
            # sphinx_app = SphinxApp(config_name='test-sphinx')
            rc = SphinxApp(**sphinx_cfg).build(sphinx_builders)
            conv = Ansi2HTMLConverter()
            # rc_all = []
            # for rc_builder, rc_status, rc_warning in rc:
            #     log.info(f"Builder(s): {rc_builder} status: {rc_status}")
            #     log.warning(f"Builder(s): {rc_builder} status: {rc_warning}")
            #     rc_all.extend([
            #         html.H1(f"Builder(s): {rc_builder}"),
            #         html.H2('Status'),
            #         html.P(dash_dangerously_set_inner_html.DangerouslySetInnerHTML(conv.convert(rc_status))),
            #         html.Hr(),
            #         html.H2('Warnings'),
            #         html.P(dash_dangerously_set_inner_html.DangerouslySetInnerHTML(conv.convert(rc_warning))),
            #         html.Hr(),
            #     ])
            # return rc_all

            tabs = []
            for rc_builder, rc_status, rc_warning in rc:
                log.info(f"Builder(s): {rc_builder} status: {rc_status}")
                log.warning(f"Builder(s): {rc_builder} status: {rc_warning}")

                tab_content = dbc.Card(
                    dbc.CardBody([
                        html.P(f"Sphinx {rc_builder.upper()} builder outputs:"),
                        dbc.Accordion([
                            dbc.AccordionItem([
                                dash_dangerously_set_inner_html.DangerouslySetInnerHTML(conv.convert(rc_status)),
                            ],
                                title="Status",
                            ),
                            dbc.AccordionItem([
                                dash_dangerously_set_inner_html.DangerouslySetInnerHTML(conv.convert(rc_warning)),
                            ],
                                title="Warning",
                            ),
                        ]),
                    ]),
                    className="mt-3",
                )
                tabs.append(
                    dbc.Tab(
                        tab_content,
                        label=rc_builder.upper(),
                        tab_id=f"tab_sphinx_builder_{rc_builder}",
                    )
                )

            return dbc.Tabs(tabs, active_tab=f"tab_sphinx_builder_{rc[0][0]}")
        else:
            rc = []
            if not sphinx_cfg:
                rc.append(html.P('Please select a documentation to build!'))
            if not len(sphinx_builders):
                rc.append(html.P('Please select at least one builder!'))
            return rc
    else:
        return None


register_page(__name__,
              path="/admin/sphinx",
              title="Sphinx Documentation Manager",
              short_name='Sphinx Doc Mgt',
              layout=layout)
