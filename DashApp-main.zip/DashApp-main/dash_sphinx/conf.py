# -*- coding: utf-8 -*-

import os
import sys
from dash_sphinx.tools import *

sys.path.append(os.path.abspath('./sphinx_ext'))

# Define ALL variables (list, dict, ...) to update
author = "Stephane ENGEL"
extensions = []
root_doc = 'index'
matex_engine = 'pdflatex'

# Overwrite with sphinx conf
if 'SPHINX_CONF' in os.environ:
    exec(open(os.environ['SPHINX_CONF']).read(), globals(), locals())

# Update extension
for extension in [
    'dash_sphinx.sphinx_ext.jsontoc',
    'dash_sphinx.sphinx_ext.dash_spa_theme',
]:
    if extension not in extensions:
        extensions.append(extension)


# Overwrite
# html_theme = 'basic'
# html_theme = 'pydata_sphinx_theme'
# html_theme = 'sphinx_book_theme'
html_theme = 'dash_spa_theme'
html_theme_options = {
    "show_toc_level": 6,
    # "display_toc": True,
}
