import logging
from .spa_config import config

# pylint: disable=unused-import
from logging import CRITICAL, ERROR, WARNING, INFO, DEBUG, NOTSET, FATAL, WARN

options = config.get('logging')


def getOptionsLevel(default='WARN'):
    return options.get('level', default_value=default)


def getLogFormat(default=None):
    return options.get('format', default_value=default)


logging.basicConfig(
    level=getOptionsLevel(),
    # format = '%(levelname)s %(asctime)s.%(msecs)03d %(module)10s/%(lineno)-5d %(message)s'
    # format='%(levelname)s %(module)13s/%(lineno)-5d %(message)s'
    format=getLogFormat('%(levelname)s %(module)13s/%(lineno)-5d %(message)s')
)

log = logging.getLogger("dash_spa")


def getLogger(name=None):
    return logging.getLogger(name)


def setLevel(level):
    log.setLevel(level=level)
