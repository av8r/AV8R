# -*- coding: utf-8 -*-

from app.database import db
from app.dashapp import create_dash
from app.modules.api import init_api
from app.server import serve_app

from dash_spa import DashSPA, page_container, spa_config
from dash_spa.logging import log
from dash_spa_admin import AdminLoginManager

from sqlalchemy_utils import database_exists

# Todo - FlaskProxy fix module
from werkzeug.middleware.proxy_fix import ProxyFix


def create_app(dash_factory) -> DashSPA:
    """Create Dash application

    Args:
        dash_factory (Dash): Callable that returns a Dash Instance

    Returns:
        Dash: Dash instance
    """

    def layout():
        return page_container

    dash_app = dash_factory()
    dash_app.layout = layout

    # Setup "flask.config"
    for flask_cfg in dash_app.flask_options if isinstance(dash_app.flask_options, list) else [dash_app.flask_options]:
        for k, v in flask_cfg.__dict__.items():
            if k == k.upper():      # only uppercase keys
                dash_app.server.config[k] = v

    # Todo - FlaskProxy fix module
    if 'SITE_PROXYFIX' in dash_app.server.config:
        dash_app.server.server.wsgi_app = ProxyFix(
            dash_app.server.wsgi_app,
            x_for=dash_app.server.config['SITE_PROXYFIX']['x_for'],
            x_proto=dash_app.server.config['SITE_PROXYFIX']['x_proto'],
            x_host=dash_app.server.config['SITE_PROXYFIX']['x_host'],
            x_port=dash_app.server.config['SITE_PROXYFIX']['x_port'],
            x_prefix=dash_app.server.config['SITE_PROXYFIX']['x_prefix'],
        )

    # SQLAlchemy
    if 'SQLALCHEMY_DATABASE_URI' in dash_app.server.config or 'SQLALCHEMY_BINDS' in dash_app.server.config:
        dash_app.db = db
        dash_app.db.init_app(dash_app.server)
        if 'SQLALCHEMY_DATABASE_URI' in dash_app.server.config \
                and not database_exists(dash_app.server.config['SQLALCHEMY_DATABASE_URI']):
            dash_app.server.app_context().push()
            try:
                dash_app.db.create_all()
                dash_app.db.session.commit()
            except Exception as e:
                log.error(f"SQLAlchemy: [{dash_app.server.config['SQLALCHEMY_DATABASE_URI']}] : {e}")
    else:
        raise spa_config.ConfigurationError("SQLAlchemy not set: add SQLALCHEMY_DATABASE_URI or SQLALCHEMY_BINDS")

    if AdminLoginManager.enabled:
        login_manager = AdminLoginManager(dash_app.server)
        login_manager.init_app(dash_app.server)

        # Optionally add admin user here or via the admin web interface
        # if login_manager.user_count() == 0:
        #     login_manager.add_user("admin", "bigjoe@gmail.com", "1234", role=['admin'])

        # Other users can also be added here. Alternatively login as 'admin'
        # and manage users from the users view.

        # if not login_manager.get_user("littlejoe@gmail.com"):
        #     login_manager.add_user("littlejoe", "littlejoe@gmail.com", "5678")

    # Flask-RestX
    if 'RESTX_ENABLED' in dash_app.server.config and dash_app.server.config['RESTX_ENABLED']:
        dash_app.server.config['API'] = init_api(dash_app.server)

    return dash_app
