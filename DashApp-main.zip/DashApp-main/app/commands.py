# -*- coding: utf-8 -*-

r"""
DESCRIPTION:
"""

import datetime
from flask import current_app
from flask.cli import click, with_appcontext
from flask_security.utils import hash_password
from app.database import db, multi_thread
# Not YET from app.modules.users.models import Role
# Not YET from app.modules.sphinxdoc.config import all_builder
all_builder = {}

@click.command('wsgi', short_help='Run a wsgi server.')
@click.option('--host', '-h', default='127.0.0.1', help='Host to bind to.')
@click.option('--port', '-p', default=5000, help='Port to bind to.')
@click.option('--threads', '-t', default=multi_thread, help=f'number of threads ({multi_thread}).')
def cli_run_wsgi(host, port, threads):
    from waitress import serve
    from . import create_app, create_dash
    serve(create_app(create_dash).server, host=host, port=port, threads=threads)


@click.command('create-database', short_help="Create/Reset database.")
@click.option('--admin/--no-admin', default=True, help='Add admin user.')
@click.option('--drop/--no-drop', default=True, help='Drop all tables.')
@with_appcontext
def cli_create_database(admin, drop):
    current_app.logger.info("Creating Database")

    if drop:
        db.drop_all()
    db.create_all()

    if admin:
        _cli_create_admin()
    else:
        db.session.commit()


@click.command('create-admin', short_help="Create admin user & role.")
@with_appcontext
def cli_create_admin():
    return _cli_create_admin()


@click.command('load-data', short_help="import dataset.")
@click.option('--threads', default=multi_thread, help=f'number of threads ({multi_thread})')
@click.option('--configfile', default='*', help=f'loader config file - glob or lit separate by "," - default: *')
@click.option('--sphinxdoc/--no-sphinxdoc', default=True, help='Rebuild sphinx documentation')
@click.option('--builder', default="all", help=f'sphinx builder, default: all ({", ".join(all_builder)}).')
@click.option('--debug/--no-debug', default=False, help='Debug - default off')
@click.option('--timeme/--no-timeme', default=False, help='Profile/Time - default off')
@with_appcontext
def cli_load_data(threads, configfile, sphinxdoc, builder, timeme, debug):
    from app.database.commands import load_all_classes

    db.create_all()
    current_app.logger.info("Loading data")
    load_all_classes(threads, configfile, True, debug, timeme)

    if sphinxdoc:
        _sphinxdoc_build(builder)


@click.command('purge-database', short_help='Purge database')
@with_appcontext
def cli_purge_database():
    from app.database.commands import purge_all_classes

    current_app.logger.info("Purge database")
    purge_all_classes()


@click.command('sphinxdoc', short_help="Build sphinx documentation.")
@click.option('--builder', default="all", help='sphinx builder, default: html (html, latex, pdflatex)')
@with_appcontext
def cli_sphinxdoc_build(builder):
    current_app.logger.info("Building Sphinx doc")
    return _sphinxdoc_build(builder)


def _sphinxdoc_build(builder):
    from .modules.sphinxdoc.builder import build_sphinxdoc_task
    return build_sphinxdoc_task("Build", builder)


def _cli_create_admin():
    current_app.logger.info("Create admin user & role")
    security = current_app.extensions.get('security')

    user_role = Role(name='user')
    super_user_role = Role(name='superuser')
    db.session.add(user_role)
    db.session.add(super_user_role)
    db.session.commit()

    security.datastore.create_user(
        first_name='Admin',
        email='admin',
        password=hash_password('admin'),
        roles=[user_role, super_user_role],
        active=True,
        confirmed_at=datetime.datetime.now()
    )

    db.session.commit()
