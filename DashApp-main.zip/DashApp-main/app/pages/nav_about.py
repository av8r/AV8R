# -*- coding: utf-8 -*-

import dash_spa as spa
from dash import html, dcc
import dash_bootstrap_components as dbc
from dash_spa.components.navbar import NavbarBase
# XXX
from dash.dependencies import Input, Output, State

tabs_styles = {
    'height': '44px'
}
tab_style = {
    'borderBottom': '1px solid #d6d6d6',
    'padding': '6px',
    'fontWeight': 'bold'
}

tab_selected_style = {
    'borderTop': '1px solid #d6d6d6',
    'borderBottom': '1px solid #d6d6d6',
    'backgroundColor': '#119DFF',
    'color': 'white',
    'padding': '6px'
}


class NavbarAbout(NavbarBase):
    nav_link_about_button = dbc.NavLink("About", id="nav_link_about_button", n_clicks=0)
    btn_about_close = dbc.Button("Close", id="btn_about_close", className="ms-auto", n_clicks=0)
    dlg_about_modal = dbc.Modal([
        dbc.ModalHeader(dbc.ModalTitle("About")),
        dbc.ModalBody(id="about_body"),
        dbc.ModalFooter(btn_about_close)
    ],
        id="dlg_about_modal",
        is_open=False,
        scrollable=True,
        centered=True,  # vertically centered
        className="g-0"
    )

    def __init__(self):
        super().__init__()
        # self.xxx = xxx

    def layout(self):
        return dbc.NavItem([
            self.nav_link_about_button,
            self.dlg_about_modal
        ])


@spa.callback(
    Output("dlg_about_modal", "is_open"),
    Output("about_body", "children"),
    [
        Input("nav_link_about_button", "n_clicks"),
        Input("btn_about_close", "n_clicks"),
    ],
    [
        State("dlg_about_modal", "is_open")
    ]
)
def display_about_modal(n1, n2, is_open):
    # {spa.__version__}')
    # XXX --> role ?
    display_sys_info = hasattr(spa.current_user, 'is_authenticated') \
                       and hasattr(spa.current_user, 'role') \
                       and 'admin' in repr(spa.current_user.role)    # repr(spa....)

    about_body = dbc.Card([
        dbc.CardHeader(
            dbc.Tabs([
                dbc.Tab(label='General', tab_id="about_tab_1"),
                dbc.Tab(label='Sys Info', tab_id="about_tab_2", disabled=not display_sys_info),
            ],
                id="about_card_tabs",
                active_tab="about_tab_1",
                style={     # fix tabs stack in column
                    'flex-direction': 'row',
                },
            ),
        ),
        dbc.CardBody(
            html.Div(id="about_card_content", className="card-text")
        )
    ])

    if n1 or n2:
        return not is_open, about_body
    else:
        return is_open, about_body


@spa.callback(
    Output('about_card_content', 'children'),
    [
        Input('about_card_tabs', 'active_tab'),
    ],
    # prevent_initial_call=True
)
def render_content(active_tab):
    if active_tab == "about_tab_1":
        item_dict = {
            'todo': 'spa.about.dict'
        }
    elif 'admin' in spa.current_user.role:
        item_dict = {
            'todo': 'spa.about_admin.dict'
        }
    else:
        item_dict = {}
    return dbc.ListGroup([
        dbc.ListGroupItem([
            html.B(f"{k}: "), html.I(v)
        ]) for k, v in item_dict.items()
    ],
        className="card-text",
        # flush=True,
    )
