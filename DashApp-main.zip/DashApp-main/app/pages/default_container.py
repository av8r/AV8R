import traceback
import dash_bootstrap_components as dbc
import dash_spa as spa
from dash import html

from app.pages.nav_about import NavbarAbout
from dash_spa.components import Footer, NavBar, NavbarBrand, NavbarLink, NavbarDropdown
from dash_spa.exceptions import InvalidAccess
from dash_spa.logging import log
from dash_spa_admin import AdminNavbarComponent

# Register pages
import dash_sphinx.sphinx_admin
import dash_sphinx.sphinx_page

# XXX
# from dash.dependencies import Input, Output, State

from app.pages import NAVBAR_PAGES
from dash_sphinx.sphinx_drop_down import SphinxDropDownMenu

page_opt = spa.config.get('app_page')

CSS = """
    .body {
        display: flex;
        flex-direction: column;
        margin: 0;
        min-height: 100vh;
    }

    header, footer {
        flex-grow: 0;
    }

    footer {
        background-color: #dedede;
    }

    main {
        flex-grow: 1;
    }

    .navbar-brand {
        text-transform: none;
    }

"""


def default_container(page, layout, **kwargs):
    """Default page content container. All pages are wrapped by this content unless
    registered with container=None or container='some_other_container

    Args:
        page: ...
        layout (Component or callable): layout to be wrapped

    Returns:
        layout wrapped by container markup
    """

    log.info("*************** default_container page=%s *********************", page['module'])

    items_dropdown = NavbarDropdown([
        dbc.DropdownMenuItem("Item 1"),
        dbc.DropdownMenuItem("Item 2"),
        dbc.DropdownMenuItem("Item 3"),
        # NavbarLink(path='/admin/sphinx'),
    ], "Items")

    try:
        NAV_BAR_ITEMS = {
            'brand': NavbarBrand([html.I(className='fas fa-fw fa-home'), f' {page_opt.get("brand", "Home")}'], '/'),
            # 'left': [NavbarLink(path=path) for path in NAVBAR_PAGES] + [items_dropdown],
            # 'left': [NavbarLink(path=path) for path in NAVBAR_PAGES] + [NavbarLink(path='/admin/sphinx')],
            'left': [SphinxDropDownMenu()],
            'right': [AdminNavbarComponent(), NavbarAbout()]
        }

        navbar = NavBar(NAV_BAR_ITEMS)
        footer = Footer(page_opt.get("footer", f'DashSPA {spa.__version__}'))


        try:
            content = layout(**kwargs) if callable(layout) else layout
        except InvalidAccess as e:

            # To force the user to the login page uncomment the following lines
            #
            # page = spa.page_for('dash_spa_admin.page')
            # content = page.layout()

            log.debug(f"InvalidAccess: {e}")
            page = spa.page_for('pages.not_found_404')
            return page.layout()

        return html.Div([
            html.Header([
                navbar.layout(),
                html.Br()
            ]),
            html.Main([
                # html.Div([
                #
                #     html.Div([
                #         html.Div(content, className="col-md-12 g-0"),
                #         # html.Div([], className="col-md-2")
                #     ], className='row')
                #
                html.Div(
                    content,
                    className='d-flex flex-column flex-grow-1'
                    # className='container d-flex flex-column flex-grow-1'
                ),
            ], role='main', className='d-flex'),
            html.Footer(footer.layout(), className='footer mt-auto')
        ], className='body')

    except Exception as e:
        log.debug(f"{e}")
        log.warning(traceback.format_exc())
        page = spa.page_for('app.pages.not_found_404')
        return page.layout()


spa.register_container(default_container)
spa.add_style(CSS)

