# -*- coding: utf-8 -*-

import functools
import time
import humanize


def timing(message=None, display=print):
    def wrap(f):
        @functools.wraps(f)
        def inner_wrap(cls=None, *args, **kwargs):
            ts = time.time()
            result = f(cls, *args, **kwargs) if cls else f(*args, **kwargs)
            te = time.time()
            if callable(display):
                display(f"{message if message else f.__name__}: "
                        f"took {humanize.precisedelta(int(te - ts), minimum_unit='microseconds')}")
            return result
        return inner_wrap
    return wrap
