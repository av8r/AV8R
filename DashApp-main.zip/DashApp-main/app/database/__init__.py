# -*- coding: utf-8 -*-

r"""
DESCRIPTION:
  - main database
"""

from flask_sqlalchemy import SQLAlchemy, Model
from sqlalchemy.ext.declarative import declarative_base

from sqlalchemy.engine import Engine
from sqlalchemy import event

import multiprocessing

Base = declarative_base()
multi_thread = 5 * multiprocessing.cpu_count()


class MyModel(Model):
    executor = None
    logger = None
    current_app_context = None

    __mapper_args__ = {
        # 'polymorphic_on': type,
        # 'polymorphic_identity': 'edge',
        'confirm_deleted_rows': False
    }

    __table_args__ = {
        'mysql_engine': 'InnoDB',
        'mysql_charset': 'utf8mb4',
        'mariadb_engine': 'InnoDB',
        'mariadb_charset': 'utf8mb4',
    }


db = SQLAlchemy()


# @event.listens_for(Engine, "first_connect")
# def set_db_connection(dbapi_connection, connection_record):
#     if not db:
#         return
#     if connection_record:
#         pass
#
#     # print(f"db.engine.driver: {db.engine.driver}")
#     if db.engine.driver == "pysqlite":
#         cursor = dbapi_connection.cursor()
#         [cursor.execute(pragma) for pragma in [
#             "PRAGMA journal_mode = WAL",  # WAL / MEMORY ?
#             "PRAGMA synchronous = OFF",
#             "PRAGMA temp_store = MEMORY",
#             "PRAGMA cache_size = 500000",
#         ]]
#         cursor.close()
