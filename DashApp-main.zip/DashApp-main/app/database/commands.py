# -*- coding: utf-8 -*-

r"""
DESCRIPTION:
  - database commands
"""

import multiprocessing
import os
import glob
import uuid
from flask import current_app


def get_cfg_list(configfiles='*'):
    """

    :param configfiles:
    :return:
    """
    cfg_list = []
    for cfg in configfiles.split(','):
        cfg_pattern = os.path.abspath(
            os.path.join(
                current_app.root_path,
                '..',
                'data',
                cfg + '.yaml'
            )
        )
        for cfg_file in glob.glob(cfg_pattern):
            if os.path.isfile(cfg_file):
                cfg_file = os.path.basename(cfg_file)
                cfg_list.append(os.path.splitext(cfg_file)[0])
    return cfg_list


def purge_all_classes():
    """

    :return:
    """
    admin = current_app.extensions.get('admin')[0]
    for _my_view in admin._views:
        model = getattr(_my_view, "model", None)
        if model:       #  and model.__name__ in purge_list
            purge = getattr(model, "purge", None)
            if callable(purge):
                current_app.logger.info(f"Purging table: {model.__name__}")
                purge()


def load_all_classes(threads, configfiles='*', wait=True, debug=False, timeme=False):
    """

    :param threads:
    :param configfiles:
    :param wait:
    :param debug:
    :param timeme:
    :return:
    """
    thread_id = None
    job_name = "load_all_classes"

    def task_init(tq):
        logger, t_id, t_thread_id, c_name = tq.get()
        logger.info(f"start: {t_id} / {t_thread_id} / {c_name}")
        # XX KO
        # CoreReloader.task_start(
        #     task_id=t_id,
        #     thread_id=t_thread_id,
        #     class_name=c_name,
        #     status=-1,
        #     message="SCHEDULING",
        # )

    def task_done(fn):
        status = False
        result = None
        msg = ""
        if fn.cancelled():
            msg = f"{fn.arg}: cancelled"
        elif fn.done():
            error = fn.exception()
            if error:
                msg = f"{fn.arg}: error returned: {error}"
                result = error
            else:
                status = True
                result = fn.result()
                msg = f"{fn.arg}: value returned (row#): {result}"
        fn.logger.info(msg)
        ### TODO CoreReloader.task_update( ....)
        return {
            'status': status,
            'message': msg,
            'task_id': fn.task_id,
            'result': result
        }

    executor = q = None
    if threads >= 1:
        from concurrent.futures import ThreadPoolExecutor
        q = multiprocessing.Queue()
        current_app.logger.info(f"Loading with threading enable {threads}.")
        executor = ThreadPoolExecutor(threads, initializer=task_init, initargs=(q,))

    admin = current_app.extensions.get('admin')[0]
    cfg_list = get_cfg_list(configfiles)
    task_ids = []
    for _my_view in admin._views:
        model = getattr(_my_view, "model", None)
        if model and model.__name__ in cfg_list:
            reload = getattr(model, "reload", None)
            if callable(reload):
                task_id = str(uuid.uuid4())
                if q:
                    q.put((current_app.logger, task_id, thread_id, model.__name__))
                if not wait:
                    task_ids.append({
                        'task_id': task_id,
                        'class_name': model.__name__,
                    })
                if threads >= 1:
                    with current_app.app_context():
                        f = executor.submit(reload, threads, current_app.app_context(), task_id, debug, timeme)
                    current_app.logger.info(f"Reloading table: {model.__name__} {f.running()}")
                    f.arg = model.__name__
                    f.task_id = task_id
                    f.logger = current_app.logger
                    f.thread_id = thread_id
                    f.add_done_callback(task_done)
                    # f.result()
                else:
                    current_app.logger.info(f"Reloading table: {model.__name__} with treading disabled.")
                    reload(threads, debug=debug, timeme=timeme)
    if executor:
        current_app.logger.info(f"Reloading all, waiting for thread completion")
        executor.shutdown(wait=True)
        current_app.logger.info(f"Reloading all -> all threads done")

    return {
        'job_name': job_name,
        'task_ids': task_ids,
    }
