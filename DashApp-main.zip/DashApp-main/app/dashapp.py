import flask
import dash_spa as spa
from dash_bootstrap_components.themes import SLATE

# from dash_spa import spa_pages

external_stylesheets = [
    "https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css",
    SLATE,
    # "https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css",
    "https://cdnjs.cloudflare.com/ajax/libs/chartist/0.11.4/chartist.min.css",
    # {
    #     'href': 'https://use.fontawesome.com/releases/v5.8.1/css/all.css',
    #     'rel': 'stylesheet',
    #     'integrity': 'sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf',
    #     'crossorigin': 'anonymous'
    # },
    # https://cdnjs.com/libraries/font-awesome
    {
        'href': 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css',
        'rel': 'stylesheet',
        'integrity': 'sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==',
        'crossorigin': 'anonymous',
        'referrerpolicy': 'no-referrer'
    },
    # "/static/dist/css/fix.css",

]

external_scripts = [
    # "https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js",
    # {
    #     'src': 'https://code.jquery.com/jquery-3.6.0.min.js',
    #     'integrity': 'sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=',
    #     'crossorigin': 'anonymous'
    # },
    # {
    #     'src': 'https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js',
    #     'integrity': 'sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx',
    #     'crossorigin': 'anonymous'
    # },
    # 'https://cdn.jsdelivr.net/npm/underscore@1.13.1/underscore-umd-min.js',
    # 'https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.7/MathJax.js?config=TeX-MML-AM_CHTML',
    # 'https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.8/clipboard.min.js',
]


logging_opt = spa.config.get('logging')


def create_dash() -> spa.DashSPA:
    flask_options = spa.config.get('flask*')
    options = spa.config.get('logging')

    server = flask.Flask(__name__)
    # server.config['SECRET_KEY'] = flask_options.SECRET_KEY

    plugins = []

    if logging_opt.get('DASH_LOGGING', default_value=False):
        plugins.append(spa.dash_logging)

    app = spa.DashSPA(__name__,
                      # include_pages_meta=True,
                      plugins=plugins,
                      prevent_initial_callbacks=True,
                      suppress_callback_exceptions=True,
                      external_stylesheets=external_stylesheets,
                      external_scripts=external_scripts,
                      server=server
                      )

    app.flask_options = flask_options

    app.logger.setLevel(options.level)

    return app
