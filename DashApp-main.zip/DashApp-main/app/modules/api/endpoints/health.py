# -*- coding: utf-8 -*-

r"""
DESCRIPTION:
  - API - health endpoint
"""

from flask_restx import Namespace, Resource

ns = Namespace('health', description='Operation related to heath')


@ns.route('/')
@ns.response(404, 'Health Not Found!')
class ReloadCollection(Resource):
    @ns.doc(security=[])
    @ns.response(200, 'Ok')
    def get(self):
        return None, 200
