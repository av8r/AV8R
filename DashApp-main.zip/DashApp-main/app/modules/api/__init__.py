# -*- coding: utf-8 -*-

r"""
DESCRIPTION:
  - API
"""

from dash_spa import current_app, spa_config
from flask import Blueprint, redirect

import os
import glob
import importlib.util
from flask_restx import Api # noqa

api_options = spa_config.config.get('api')

default_api_version = api_options.get('default_api_version', None)

# TODO: if configured ...
authorizations = {
    'apikey': {
        'type': 'apiKey',
        'in': 'header',
        'name': 'X-API-KEY'
    },
    'BasicAuth': {
        'type': 'basic',
        'in': 'header',
        'name': 'Authorization'
    }
}


def init_api(server):
    # TODO: test if defined and loop thru configured api ...
    if not default_api_version:
        raise spa_config.ConfigurationError("Missing 'default_api_version'")

    api_default_options = spa_config.config.get(f"api:{default_api_version}")

    api_default_version_bp = Blueprint(api_default_options.get('api_name', 'api'),
                                       __name__,
                                       template_folder='templates',
                                       static_folder='static',
                                       static_url_path='/static',
                                       )
    # doc: https://flask-restx.readthedocs.io/en/latest/api.html
    api = Api(
        api_default_version_bp,
        version=api_default_options.get('api_version', '1.0'),
        title=api_default_options.get('api_title', None),
        description=api_default_options.get('api_description', None),
        terms_url=api_default_options.get('api_terms_url', None),
        license=api_default_options.get('api_license', None),
        contact=api_default_options.get('api_contact', None),
        contact_url=api_default_options.get('api_contact_url', None),
        contact_email=api_default_options.get('api_contact_email', None),
        authorizations=authorizations,
        # TODO / ENH
        # # Set globaly apikey sec -- see health endpoint
        # # security=['apikey'],
        security=None,
        doc=api_default_options.get('api_doc', '/'),
        # default='default',
        # default_label='Default namespace',
        # default_mediatype='application/json',
        validate=api_default_options.get('api_validate', True),       # None
        # tags=None,
        # prefix='',
        ordered=api_default_options.get('api_ordered', True),       # False
        # decorators=None,
        # catch_all_404s=False,
        # serve_challenge_on_401=False,
        # format_checker=None,
        # url_scheme=None,
        # default_swagger_filename='swagger.json',
    )

    # add dynamically all namespace from XXXX
    ns_glob_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..', '*', 'endpoints', '*.py'
    )
    for ns_module in glob.glob(ns_glob_dir):
        ns_module = os.path.abspath(ns_module)
        if os.path.basename(ns_module).startswith('_'):
            current_app.logger.debug(f"skipping {ns_module}")
            continue
        spec = importlib.util.spec_from_file_location('ns_name', ns_module)
        api_ns = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(api_ns)

        if hasattr(api_ns, 'ns'):
            current_app.logger.debug(f"Loading Flask-RestX NS from : {ns_module}")
            try:
                api.add_namespace(api_ns.ns)
            except Exception as e:
                current_app.logger.warning(f"{ns_module} : {e}")
        else:
            current_app.logger.warning(f"{ns_module} has no ns method")

    # register blueprint for all api version
    # server.regiter_blueprint(api_v0, url_prefix='/api/v0')
    server.register_blueprint(api_default_version_bp, url_prefix=api_default_options.get('api_url_prefix', '/api'))

    # default route to last api version
    @server.route('/api/')
    @server.route('/api/<path:api_path>')
    def redirect_default_api(api_path=None):
        if not api_path:
            api_path = ''
        return redirect(f'/api/{default_api_version}/{api_path}')

    # custom CSS (KO)
    # @server.route('/swaggerui/swagger-ui.css')
    # def custom_swagger_css_theme():
    #     return redirect(url_for('api_v1.static'), filename='...')

    return api
