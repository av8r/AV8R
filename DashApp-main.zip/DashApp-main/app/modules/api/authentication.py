# -*- coding: utf-8 -*-

r"""
DESCRIPTION:
  - API - Authentication
"""

from flask import current_app, request
from flask_login import current_user, login_user
from app.modules.users.models import User
from functools import wraps


def token_required(f):
    @wraps(f)
    def decorate(*args, **kwargs):
        token = None
        basic = None

        # Token
        if 'X-API-KEY' in request.headers:
            token = request.headers['X-API-KEY']
            if token == current_app.config['SITE_API_KEY']:
                return f(*args, **kwargs)
            else:
                return {'message': 'Token is wrong.'}, 401
        # BASIC
        elif 'Authorization' in request.headers:
            auth = request.authorization
            if auth:
                # see app.dashapp.app
                user = User.query.filter_by(email=auth.username).first()
                if user and user.check_password(password=auth.password):
                    login_user(user)
                else:
                    return {'message': 'Wrong Login/Password.'}, 401
                return f(*args, **kwargs)
            else:
                return {'message': 'Wrong Login/Password.'}, 401
        # Active Session
        elif current_user.is_authenticated:
            return f(*args, **kwargs)
        if not token or not basic:
            return {'message': 'Token/Login-Password is missing.'}, 401
        # Should not be there ???
        return {'message': 'Invalid method.'}, 401
    return decorate
