# -*- coding: utf-8 -*-

r"""
DESCRIPTION:
  - API - business
"""

from flask import request   # , current_app
from flask_restx import reqparse
from app import db


pagination_arguments = reqparse.RequestParser()
pagination_arguments.add_argument('page', type=int, required=False, default=None)
pagination_arguments.add_argument('per_page', type=int, required=False,
                                  choices=[5, 10, 20, 30, 40, 50, 200], default=200)


def create_item(table_name, data):
    item_id = data.get('id')
    item = table_name(**data)

    if item_id:
        item.id = item_id

    db.session.add(item)
    db.session.flush()
    db.session.commit()
    return item.id


def read_items(table_name):
    args = pagination_arguments.parse_args()

    # sorting keys
    other_args = dict(request.args)
    if args['page']:
        del other_args['page']
    if args['per_page']:
        del other_args['per_page']

    if not len(other_args):     # Paginate unsorted
        if args['page']:
            query_list = table_name.query.paginate(
                args['page'],
                args['per_page'],
                False)
            # nb_items = table_name.query.count()
            return query_list.items, 200, {'X-Total-Count': query_list.total}
        else:                   # all data unsorted
            query_list = table_name.query.all()
            return query_list
    else:                       # sorted (via other ags)
        # build filters
        query = None
        for _column_name in other_args:
            try:
                if query:
                    query = query.filter(getattr(table_name, _column_name).like("%"+other_args[_column_name]+"%"))
                else:
                    query = table_name.query.filter(getattr(table_name, _column_name).like("%"+other_args[_column_name]+"%"))
            except NotImplementedError:
                # TODO ...
                pass

        if not query:       # pass
            query = table_name.query

        if args['page']:    # paginated data
            query_list = query.paginate(
                args['page'],
                args['per_page'],
                False)
            # nb_items = query.count()
            return query_list.items, 200, {'X-Total-Count': query_list.total}
        else:                   # all data sorted
            query_list = query.all()
            return query_list


def update_item(table_name, item_id, data):
    item = table_name.query.filter(table_name.id == item_id).one()

    for k, v in data.items():
        try:
            setattr(item, k, v)
        except AttributeError:
            print("Warning: {} not set".format(k, v))
            pass

    db.session.add(item)
    db.session.flush()
    db.session.commit()


def delete_item(table_name, item_id):
    item = table_name.query.filter(table_name.id == item_id).one()

    db.session.delete(item)
    db.session.flush()
    db.session.commit()
