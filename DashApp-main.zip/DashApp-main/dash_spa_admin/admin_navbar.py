from abc import abstractmethod
from flask import current_app as app, url_for
from dash_spa import current_user
from dash import html
import dash_bootstrap_components as dbc

from dash_sphinx import SPHINX_ADMIN_ROUTE
from .views.common import LOGIN_ENDPOINT, LOGOUT_ENDPOINT, USERS_ENDPOINT, REGISTER_ADMIN_ENDPOINT


class AdminNavbarComponent:

    def __init__(self):
        pass

    @abstractmethod
    def menu_items(self):
        """User defined components for NavBar My Account dropdown"""
        return [
            dbc.DropdownMenuItem(
                [html.I(className="fas fa-fw fa-envelope"), " Messages"],
                href="#"),
            dbc.DropdownMenuItem(
                [html.I(className="fas fa-fw fa-address-card"), " Profile"],
                href="#",
            )

        ]

    def account_dropdown(self):

        children = self.menu_items()

        if app.login_manager.isAdmin():
            children.append(dbc.DropdownMenuItem(
                [html.I(className="fas fa-fw fa-cog"), " Users"],
                href=app.login_manager.path_for(USERS_ENDPOINT))
            )

        if hasattr(current_user, 'is_authenticated') \
            and hasattr(current_user, 'role') \
            and any(_role_ in repr(current_user.role) for _role_ in ('admin', 'dev')):
            children.append(html.Div(className='dropdown-divider'))
            children.append(dbc.DropdownMenuItem(
                    [html.I(className="fas fa-fw fa-cog"), " Sphinx Admin"],
                    href=SPHINX_ADMIN_ROUTE,
                ))
            children.append(dbc.DropdownMenuItem(
                    [html.I(className="fas fa-fw fa-code"), " Swagger"],
                    href=url_for('redirect_default_api'),
                    target='_blank',
                    external_link=True
                )
            )

        children.append(html.Div(className='dropdown-divider'))
        children.append(
            dbc.DropdownMenuItem([html.I(className='fas fa-fw fa-sign-out-alt'), ' Sign out'],
                                 href=app.login_manager.path_for(LOGOUT_ENDPOINT))
        )

        menu = dbc.DropdownMenu(
            children=children,
            nav=True,
            in_navbar=True,
            # label="My Account",
            label=f" {current_user.name}",
            right=True
        )

        icon = html.I(className="fa fa fa-user", style={'position': 'relative', 'left': '0px'})

        return html.Div(['', icon, menu], style={'padding': '0'}, className='d-flex align-items-center nav-link')

    def signin_link(self):
        try:
            if app.login_manager.user_count() > 0:
                href = app.login_manager.path_for(LOGIN_ENDPOINT)
            else:
                href = app.login_manager.path_for(REGISTER_ADMIN_ENDPOINT)
            return dbc.NavItem(dbc.NavLink([html.I(className='fas fa-fw fa-sign-in-alt'), ' Sign in'], href=href))
        except:
            return html.Div('')

    def layout(self, **kwargs):
        if current_user and not current_user.is_anonymous:
            return self.account_dropdown()
        return self.signin_link()
