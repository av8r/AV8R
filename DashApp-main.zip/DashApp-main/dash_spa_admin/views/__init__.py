from .forgot_code_view import forgotCodeForm
from .forgot_password_view import forgotPasswordForm
from .forgot_view import forgotForm

from .login_view import loginForm
from .register_view import registerForm
from .admin_register_view import adminRegistrationForm

from .logout_view import logoutView
from .users_view import usersView

from .register_verify_view import registerVerifyForm