#!/bin/bash
DIRNAME=$(cd $(dirname $0) && pwd)

## ./.venv/bin/gunicorn app
## ./.venv/bin/gunicorn app:application

$  ${DIRNAME}/.venv/bin/flask run -h $(hostname)

FLASK_ENV=${1:-development} FLASK_APP=app \
  ${DIRNAME}/.venv/bin/flask run -h 0.0.0.0

