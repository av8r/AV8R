#!/bin/bash
set -e

DIRNAME=$( cd $(dirname $0) && pwd)
VENVDIR=".venv"
OVENV=${VIRTUAL_ENV}

cd ${DIRNAME}
[ ! -f "${VENVDIR}/bin/activate" ]  \
  && virtualenv -p $(which python3) ${VENVDIR}
[ -z "${VIRTUAL_ENV}" ] \
  && source ${VENVDIR}/bin/activate

if [ -f "requirements" ] ; then
  ${VENVDIR}/bin/pip list --outdated --format=freeze \
    | grep -v '^\-e' \
    | cut -d = -f 1  \
    | xargs -r -n1 ${VENVDIR}/bin/pip install -U 
else
  ${VENVDIR}/bin/pip install --upgrade pip
  ${VENVDIR}/bin/pip install \
      flask \
      flask-restplus \
      flask-admin \
      flask-login \
      Flask-Bcrypt \
      Flask-SQLAlchemy \
      Flask-Migrate \
      Flask-Script \
      Flask-Bootstrap \
      Flask-Navbar \
      Flask-Security \
      Flask-WTF \
      psycopg2 \
      gunicorn \
      uwsgi \
      wheel \
      Jinja2 \
      aumbry[yaml]
  pip freeze > requirements.txt
fi

echo "cd app && gunicorn app:app"

[ -z "${OVENV}" ] && bash
:
