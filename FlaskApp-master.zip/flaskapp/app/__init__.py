import logging.config

import os
from flask import Flask, url_for, redirect, render_template, send_from_directory, request, abort, Blueprint
import jinja2.exceptions
## from flask_sqlalchemy import SQLAlchemy
from flask_security import Security, SQLAlchemyUserDatastore, \
     UserMixin, RoleMixin, login_required, current_user
from flask_security.utils import encrypt_password
import flask_admin
from flask_admin.contrib import sqla
from flask_admin import helpers as admin_helpers
from flask_login import LoginManager, login_required, login_user, logout_user, current_user
from flask_bootstrap import Bootstrap

# Nav
from flask_navbar import Nav, register_renderer
from flask_navbar.elements import *
## from flask_navbar.renderers import ExtBootstrapRenderer



# API
from app.api.blog.endpoints.posts import ns as blog_posts_namespace
from app.api.blog.endpoints.categories import ns as blog_categories_namespace
from app.api.restplus import api
# Database
from app.database import db, reset_database
from app.database.models import Role, User, \
        Post, Category



###############################################################################
#
# View
#
###############################################################################

# Create customized model view class
class MyModelView(sqla.ModelView):

    def is_accessible(self):
        if not current_user.is_active or not current_user.is_authenticated:
            return False

        if current_user.has_role('superuser'):
            return True

        return False

    def _handle_view(self, name, **kwargs):
        """
        Override builtin _handle_view in order to redirect users when a view is not accessible.
        """
        if not self.is_accessible():
            if current_user.is_authenticated:
                # permission denied
                abort(403)
            else:
                # login
                return redirect(url_for('security.login', next=request.url))

###############################################################################
#
# Navbars
#
###############################################################################

# https://github.com/mbr/flask-nav/issues/18
def mynavbar():
    return Navbar(
        View(settings['site_title'], 'index'),
        NavUl(
            View('Our Mission', 'index', icon='fa fa-fw fa-home'),
            Subgroup(
                'Pages',
                View('Charts', 'pages', pagename='examples/charts', icon='fa fa-fw fa-bar-chart-o'),
                View('Dashboard', 'pages', pagename='examples/dashboard', icon='fa fa-fw'),
                View('Forms', 'pages', pagename='examples/forms', icon='fa fa-fw'),
                View('Tables', 'pages', pagename='examples/tables', icon='fa fa-fw'),
                Separator(),
                View('Profile', 'pages', pagename='examples/profile', icon='fa fa-fw'),
                View('Settings', 'pages', pagename='examples/settings', icon='fa fa-fw'),
                Separator(),
                View('Font Awesome', 'pages', pagename='examples/awesome', icon='fa fa-fw'),
                View('BS Elements', 'pages', pagename='examples/bootstrap-elements', icon='fa fa-fw'),
                View('BS Grid', 'pages', pagename='examples/bootstrap-grid', icon='fa fa-fw'),
                Separator(),
                View('Licence', 'pages', pagename='licence', icon='fa fa-fw'),
            ),
            Subgroup(
                'Products',
                View('Wg240-Series', 'index', product='wg240', icon='fa fa-fw fa-home'),
                View('Wg250-Series', 'index', product='wg250', icon='fa fa-fw fa-home'),
                Separator(),
                Text('Discontinued Products'),
                View('Wg10X', 'index', product='wg10x', icon='fa fa-fw fa-home'),
            ),
            View('API', 'api.doc', icon='fa fa-fw fa-code'),
            # Link('Tech Support', 'http://techsupport.invalid/widgits_inc'),
            navbar_right=False
        ),
        Search('/search', navbar_right=False, icon='fa fa-search', btn_text='Go',
               input_placeholder='Search...', input_name='q', input_id='q', ),
        # navbar_inverse=True,
        # navbar_fixed='top',
        # logo_filename='logo.png'
    )

def secnavbar():
    secnav = list(mynavbar().items)

    # About
    aboutitems = []
    aboutitems.append( 'About' )
    aboutitems.append( View('Licence', 'pages', pagename='licence', icon='fa fa-fw fa-tags') )
    if current_user.is_authenticated and current_user.has_role('superuser'):
        aboutitems.append( View('API', 'api.doc', icon='fa fa-fw fa-code') ),
        aboutitems.append( Separator() ),
        aboutitems.append( Text('Examples - Page') ),
        aboutitems.append( View('Charts', 'pages', pagename='examples/charts', icon='fa fa-fw fa-bar-chart-o') ),
        aboutitems.append( View('Dashboard', 'pages', pagename='examples/dashboard', icon='fa fa-fw fa-dashboard') ),
        aboutitems.append( View('Forms', 'pages', pagename='examples/forms', icon='fa fa-fw fa-edit') ),
        aboutitems.append( View('Tables', 'pages', pagename='examples/tables', icon='fa fa-fw fa-table') ),
        aboutitems.append( Separator() ),
        aboutitems.append( Text('Examples - Elements') ),
        aboutitems.append( View('Font Awesome', 'pages', pagename='examples/awesome', icon='fa fa-fw fa-font') ),
        aboutitems.append( View('BS Elements', 'pages', pagename='examples/bootstrap-elements', icon='fa fa-fw fa-desktop') ),
        aboutitems.append( View('BS Grid', 'pages', pagename='examples/bootstrap-grid', icon='fa fa-fw fa-wrench') ),
        ## aboutitems.append( Separator() ),
        ## aboutitems.append( View('Profile', 'pages', pagename='examples/profile', icon='fa fa-fw') ),
        ## aboutitems.append( View('Settings', 'pages', pagename='examples/settings', icon='fa fa-fw') ),

    secnav.append(
        NavUl(
            Subgroup(
                *aboutitems
            ),
            navbar_right=True
        )
    )


    if not current_user.is_authenticated:
        secnav.append(
            NavUl(
                View('Log in', 'security.login', icon='fa fa-sign-in'),
                navbar_right=True
            )
        )
    else:
        # https://ludusrusso.cc/2016/12/27/tutorial-flask/
        loginitems = []
        loginitems.append( (current_user.first_name or current_user.email) )
        loginitems.append(Link('Profile','/profile', icon='fa fa-user'))
        # XXX admin or if current_user.has_role('superuser'):
        if current_user.has_role('superuser'):
            loginitems.append(View('Admin','admin.index', icon='fa fa-gear'))
        loginitems.append(View('Log out', 'security.logout', icon='fa fa-sign-out'))
        secnav.append(
            NavUl(
                Subgroup(*loginitems),
                navbar_right=True
            )
        )

    return Navbar(
            View(settings['site_title'], 'index', icon='fa fa-home'),
            *secnav,
            navbar_inverse=True,
            navbar_fixed='top',
            # logo_filename='logo.png'
    )


def initialize_app(flask_app, settings):

    # setup the login manager
    login_manager = LoginManager()
    login_manager.init_app(flask_app)
    login_manager.login_view = 'login'

    # Setup Flask-Security
    user_datastore = SQLAlchemyUserDatastore(db, User, Role)
    security = Security(flask_app, user_datastore)

    # Create admin
    admin = flask_admin.Admin(
        flask_app,
        settings['site_title'],
        base_template='site_admin_master.html',
        template_mode='bootstrap3',
    )

    # Add model views
    admin.add_view(MyModelView(User, db.session, category='Users'))
    admin.add_view(MyModelView(Role, db.session, category='Users'))
    admin.add_view(MyModelView(Post, db.session, category='Blog'))
    admin.add_view(MyModelView(Category, db.session, category='Blog'))

    # define a context processor for merging flask-admin's template context into the
    # flask-security views.
    @security.context_processor
    def security_context_processor():
        return dict(
            admin_base_template=admin.base_template,
            admin_view=admin.index_view,
            h=admin_helpers,
            get_url=url_for
    )

    # API
    blueprint = Blueprint('api', __name__, url_prefix='/api')
    api.init_app(blueprint)
    api.add_namespace(blog_posts_namespace)
    api.add_namespace(blog_categories_namespace)
    flask_app.register_blueprint(blueprint)

    # DB
    db.init_app(flask_app)

    # Build a sample db on the fly, if one does not exist yet.
    app_dir = os.path.realpath(os.path.dirname(__file__))
    database_path = os.path.join(app_dir, flask_app.config['DATABASE_FILE'])
    if not os.path.exists(database_path):
        with flask_app.app_context():
            reset_database()

            user_role = Role(name='user')
            super_user_role = Role(name='superuser')
            db.session.add(user_role)
            db.session.add(super_user_role)
            db.session.commit()

            test_user = user_datastore.create_user(
                first_name='Admin',
                email='admin',
                password=encrypt_password('admin'),
                roles=[user_role, super_user_role]
            )
            db.session.commit()

    # Nav
    nav = Nav()
    nav.register_element('mynavbar', mynavbar)
    nav.register_element('secnavbar', secnavbar)
    nav.init_app(flask_app)


def route_app(flask_app, settings):
    @flask_app.context_processor
    def inject_dict_for_all_templates():
        return dict(settings = settings)

    # Flask views
    @flask_app.route('/')
    def index():
        return render_template('pages/index.html', user=current_user)

    @flask_app.route('/<path:pagename>')
    def pages(pagename):
        return render_template('pages/'+pagename+'.html')

    @flask_app.route('/<path:resource>')
    def serveStaticResource(resource):
    	return send_from_directory('static/', resource)

    @flask_app.errorhandler(jinja2.exceptions.TemplateNotFound)
    def template_not_found(e):
        return not_found(e)

    @flask_app.errorhandler(404)
    def not_found(e):
        return '<strong>Page Not Found!</strong>', 404

    # old browsers
    @flask_app.route('/favicon.ico')
    def favicon():
        return send_from_directory(os.path.join(flask_app.root_path, 'static'),
                               'images/favicon.ico', mimetype='image/vnd.microsoft.icon')

### XXX get from config  OR db ?
def get_settings():
    return {
            'head_description': "",
            'head_author': "",
            'head_title': "Macchiati.ORG",
            'site_title': "Macchiati",
            'site_footer': "<a href='#'>(c) Steph</a>"
         }
settings = get_settings()

# http://flask.pocoo.org/docs/1.0/tutorial/factory/
def create_app(test_config=None):
    # create and configure the app
    app = Flask(__name__)

    # Install our Bootstrap extension
    Bootstrap(app)


    # Logging
    logging_conf_path = os.path.normpath(os.path.join(os.path.dirname(__file__), './logging.conf'))
    logging.config.fileConfig(logging_conf_path)
    log = logging.getLogger(__name__)

    # Config
    if test_config is None:
        # load the instance config, if it exists, when not testing
        app.config.from_pyfile('config.py', silent=True)
    else:
        # load the test config if passed in
        app.config.from_mapping(test_config)

    # settings 
    # settings = get_settings()

    # Initialize
    initialize_app(app, settings)

    # Routes
    route_app(app, settings)

    ## log.info('>>>>> Starting server at http://{}/api/ <<<<<'.format(app.config['SERVER_NAME']))
    return app


application=create_app()
#######

def main():
    ## application=create_app()
    application.run(debug=app.config['FLASK_DEBUG'], host='0.0.0.0')
    return aplicationp

if __name__ == '__main__':
    # Start app
    application=main()
