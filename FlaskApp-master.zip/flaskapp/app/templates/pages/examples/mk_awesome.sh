#!/bin/bash

DIRNAME=$(cd $(dirname $0) && pwd)
AWESOME_CSS_DIR=$(cd ${DIRNAME}/../../static/vendor/font-awesome/css && pwd)
XOUTPUT_HTML=$(basename $0 .sh)

function all_fa() {
  grep -B1 "content:" ${AWESOME_CSS_DIR}/font-awesome.css | awk -F: '/^\.fa/ {print $1}' | while read _dfa_; do
    _fa_=${_dfa_##.}
    echo "<li><i class=\"fa ${_fa_}\"></i> <span class="icon-name">${_fa_}</span></li>"
  done
}

echo 

cat << _EOF | tee "${DIRNAME}/${XOUTPUT_HTML##mk_}.html"
{% extends 'site_template.html' %}

{% block body %}
	<div id="page-wrapper">

		<div class="container-fluid">

			<!-- Page Heading -->
			<div class="row">
				<div class="col-lg-12">
					<h1 class="page-header">
						Awesome Font
					</h1>
					<ol class="breadcrumb">
						<li>
							<i class="fa fa-dashboard"></i>  <a href="/">Pages</a>
						</li>
						<li class="active">
							<i class="fa fa-font"></i> Awesome Font
						</li>
					</ol>
				</div>
			</div>
			<!-- /.row -->

      <!-- FA -->
			<div class="row">
				<div class="col-lg-6">
					<h2>Awesome List</h2>
          <div id="font-awesome-list">
            <ul class="font-group">
$(all_fa)
            </ul>
            </div>
				</div>
			</div>
      <!-- /FA -->

		</div>
		<!-- /.container-fluid -->

	</div>
	<!-- /#page-wrapper -->
{% endblock %}
_EOF

exit
