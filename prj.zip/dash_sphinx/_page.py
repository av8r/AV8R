html.HTML(
    children=[
        html.HEAD(
            children=[
                html.Title(
                    children=[
                        "Welcome to demo’s documentation! — demo demo documentation"
                    ]
                )
            ]
        ),
        html.BODY(
            children=[
                dcc.Link(className="skip-link", children=["Skip to main content"]),
                dbc.Label(className="overlay overlay-primary", children=[]),
                dbc.Label(className="overlay overlay-secondary", children=[]),
                html.Div(
                    className="search-button__wrapper",
                    children=[
                        html.Div(className="search-button__overlay", children=[]),
                        dbc.Container(
                            className="search-button__search-container",
                            children=[
                                html.I(
                                    className="fa-solid fa-magnifying-glass",
                                    children=[],
                                ),
                                html.Span(
                                    className="search-button__kbd-shortcut",
                                    children=[
                                        html.Kbd(
                                            className="kbd-shortcut__modifier",
                                            children=["Ctrl"],
                                        ),
                                        html.Kbd(children=["K"]),
                                    ],
                                ),
                            ],
                        ),
                    ],
                ),
                dbc.Nav(
                    className="bd-header navbar navbar-expand-lg bd-navbar",
                    children=[
                        html.Div(
                            className="bd-header__inner bd-page-width",
                            children=[
                                dbc.Label(
                                    className="sidebar-toggle primary-toggle",
                                    children=[
                                        html.Span(
                                            className="fa-solid fa-bars", children=[]
                                        )
                                    ],
                                ),
                                dbc.Navbar(
                                    className="navbar-header-items__start",
                                    children=[
                                        dbc.Navbar(
                                            className="navbar-item",
                                            children=[
                                                dbc.Navbar(
                                                    className="navbar-brand logo",
                                                    children=[
                                                        html.P(
                                                            className="title logo__title",
                                                            children=[
                                                                "demo demo documentation"
                                                            ],
                                                        )
                                                    ],
                                                )
                                            ],
                                        )
                                    ],
                                ),
                                dbc.Col(
                                    className="col-lg-9 navbar-header-items",
                                    children=[
                                        html.Div(
                                            className="me-auto navbar-header-items__center",
                                            children=[
                                                dbc.Navbar(
                                                    className="navbar-item",
                                                    children=[
                                                        dbc.Nav(
                                                            className="navbar-nav",
                                                            children=[
                                                                html.P(
                                                                    className="sidebar-header-items__title",
                                                                    children=[
                                                                        "Site Navigation"
                                                                    ],
                                                                ),
                                                                dbc.Nav(
                                                                    className="bd-navbar-elements navbar-nav",
                                                                    children=[],
                                                                ),
                                                            ],
                                                        )
                                                    ],
                                                )
                                            ],
                                        ),
                                        dbc.Navbar(
                                            className="navbar-header-items__end",
                                            children=[
                                                dbc.Container(
                                                    className="navbar-item navbar-persistent--container",
                                                    children=[],
                                                ),
                                                dbc.Navbar(
                                                    className="navbar-item", children=[]
                                                ),
                                            ],
                                        ),
                                    ],
                                ),
                                dbc.Navbar(
                                    className="navbar-persistent--mobile", children=[]
                                ),
                                dbc.Label(
                                    className="sidebar-toggle secondary-toggle",
                                    children=[
                                        html.Span(
                                            className="fa-solid fa-outdent", children=[]
                                        )
                                    ],
                                ),
                            ],
                        )
                    ],
                ),
                dbc.Container(
                    className="bd-container",
                    children=[
                        html.Div(
                            className="bd-container__inner bd-page-width",
                            children=[
                                html.Div(
                                    className="bd-sidebar-primary bd-sidebar hide-on-wide",
                                    children=[
                                        html.Div(
                                            className="sidebar-header-items sidebar-primary__section",
                                            children=[
                                                html.Div(
                                                    className="sidebar-header-items__center",
                                                    children=[
                                                        dbc.Navbar(
                                                            className="navbar-item",
                                                            children=[
                                                                dbc.Nav(
                                                                    className="navbar-nav",
                                                                    children=[
                                                                        html.P(
                                                                            className="sidebar-header-items__title",
                                                                            children=[
                                                                                "Site Navigation"
                                                                            ],
                                                                        ),
                                                                        dbc.Nav(
                                                                            className="bd-navbar-elements navbar-nav",
                                                                            children=[],
                                                                        ),
                                                                    ],
                                                                )
                                                            ],
                                                        )
                                                    ],
                                                ),
                                                html.Div(
                                                    className="sidebar-header-items__end",
                                                    children=[
                                                        dbc.Navbar(
                                                            className="navbar-item",
                                                            children=[],
                                                        )
                                                    ],
                                                ),
                                            ],
                                        ),
                                        html.Div(
                                            className="sidebar-primary-items__end sidebar-primary__section",
                                            children=[],
                                        ),
                                        html.Div(
                                            id="rtd-footer-container", children=[]
                                        ),
                                    ],
                                ),
                                html.Div(
                                    className="bd-content",
                                    children=[
                                        dbc.Container(
                                            className="bd-article-container",
                                            children=[
                                                html.Div(
                                                    className="bd-header-article",
                                                    children=[],
                                                ),
                                                html.Div(id="searchbox", children=[]),
                                                html.Article(
                                                    className="bd-article",
                                                    children=[
                                                        html.Section(
                                                            id="welcome-to-demo-s-documentation",
                                                            children=[
                                                                html.H1(
                                                                    children=[
                                                                        "Welcome to demo’s documentation!",
                                                                        html.A(
                                                                            className="headerlink",
                                                                            children=[
                                                                                "#"
                                                                            ],
                                                                        ),
                                                                    ]
                                                                ),
                                                                html.Div(
                                                                    className="toctree-wrapper compound",
                                                                    children=[],
                                                                ),
                                                            ],
                                                        ),
                                                        html.Section(
                                                            id="indices-and-tables",
                                                            children=[
                                                                html.H1(
                                                                    children=[
                                                                        "Indices and tables",
                                                                        html.A(
                                                                            className="headerlink",
                                                                            children=[
                                                                                "#"
                                                                            ],
                                                                        ),
                                                                    ]
                                                                ),
                                                                html.Ul(
                                                                    className="simple",
                                                                    children=[
                                                                        html.Li(
                                                                            children=[
                                                                                html.P(
                                                                                    children=[
                                                                                        html.A(
                                                                                            className="reference internal",
                                                                                            children=[
                                                                                                html.Span(
                                                                                                    className="std std-ref",
                                                                                                    children=[
                                                                                                        "Index"
                                                                                                    ],
                                                                                                )
                                                                                            ],
                                                                                        )
                                                                                    ]
                                                                                )
                                                                            ]
                                                                        ),
                                                                        html.Li(
                                                                            children=[
                                                                                html.P(
                                                                                    children=[
                                                                                        html.A(
                                                                                            className="reference internal",
                                                                                            children=[
                                                                                                html.Span(
                                                                                                    className="std std-ref",
                                                                                                    children=[
                                                                                                        "Module Index"
                                                                                                    ],
                                                                                                )
                                                                                            ],
                                                                                        )
                                                                                    ]
                                                                                )
                                                                            ]
                                                                        ),
                                                                        html.Li(
                                                                            children=[
                                                                                html.P(
                                                                                    children=[
                                                                                        html.A(
                                                                                            className="reference internal",
                                                                                            children=[
                                                                                                html.Span(
                                                                                                    className="std std-ref",
                                                                                                    children=[
                                                                                                        "Search Page"
                                                                                                    ],
                                                                                                )
                                                                                            ],
                                                                                        )
                                                                                    ]
                                                                                )
                                                                            ]
                                                                        ),
                                                                    ],
                                                                ),
                                                            ],
                                                        ),
                                                    ],
                                                ),
                                                html.Footer(
                                                    className="bd-footer-article",
                                                    children=[
                                                        html.Div(
                                                            className="footer-article-items footer-article__inner",
                                                            children=[
                                                                html.Div(
                                                                    className="footer-article-item",
                                                                    children=[
                                                                        html.Div(
                                                                            className="prev-next-area",
                                                                            children=[],
                                                                        )
                                                                    ],
                                                                )
                                                            ],
                                                        )
                                                    ],
                                                ),
                                            ],
                                        ),
                                        html.Div(
                                            className="bd-sidebar-secondary bd-toc",
                                            children=[
                                                html.Div(
                                                    className="sidebar-secondary-items sidebar-secondary__inner",
                                                    children=[
                                                        html.Div(
                                                            className="sidebar-secondary-item",
                                                            children=[
                                                                html.Div(
                                                                    className="page-toc tocsection onthispage",
                                                                    children=[
                                                                        html.I(
                                                                            className="fa-solid fa-list",
                                                                            children=[],
                                                                        )
                                                                    ],
                                                                ),
                                                                dbc.Nav(
                                                                    className="bd-toc-nav page-toc",
                                                                    children=[
                                                                        html.Ul(
                                                                            className="visible nav section-nav flex-column",
                                                                            children=[
                                                                                html.Li(
                                                                                    className="toc-h1 nav-item toc-entry",
                                                                                    children=[
                                                                                        dcc.Link(
                                                                                            className="reference internal nav-link",
                                                                                            children=[
                                                                                                "Welcome to demo’s documentation!"
                                                                                            ],
                                                                                        )
                                                                                    ],
                                                                                ),
                                                                                html.Li(
                                                                                    className="toc-h1 nav-item toc-entry",
                                                                                    children=[
                                                                                        dcc.Link(
                                                                                            className="reference internal nav-link",
                                                                                            children=[
                                                                                                "Indices and tables"
                                                                                            ],
                                                                                        )
                                                                                    ],
                                                                                ),
                                                                            ],
                                                                        )
                                                                    ],
                                                                ),
                                                            ],
                                                        ),
                                                        html.Div(
                                                            className="sidebar-secondary-item",
                                                            children=[
                                                                html.Div(
                                                                    className="tocsection sourcelink",
                                                                    children=[
                                                                        html.A(
                                                                            children=[
                                                                                html.I(
                                                                                    className="fa-solid fa-file-lines",
                                                                                    children=[],
                                                                                )
                                                                            ]
                                                                        )
                                                                    ],
                                                                )
                                                            ],
                                                        ),
                                                    ],
                                                )
                                            ],
                                        ),
                                    ],
                                ),
                                html.Footer(className="bd-footer-content", children=[]),
                            ],
                        )
                    ],
                ),
                html.Footer(
                    className="bd-footer",
                    children=[
                        html.Div(
                            className="bd-footer__inner bd-page-width",
                            children=[
                                html.Div(
                                    className="footer-items__start",
                                    children=[
                                        html.Div(
                                            className="footer-item",
                                            children=[
                                                html.P(
                                                    className="copyright",
                                                    children=[
                                                        "© Copyright 2023, steph.",
                                                        html.Br(children=[]),
                                                    ],
                                                )
                                            ],
                                        ),
                                        html.Div(
                                            className="footer-item",
                                            children=[
                                                html.P(
                                                    className="sphinx-version",
                                                    children=[
                                                        "Created using",
                                                        html.A(children=["Sphinx"]),
                                                        html.Br(children=[]),
                                                    ],
                                                )
                                            ],
                                        ),
                                    ],
                                ),
                                html.Div(
                                    className="footer-items__end",
                                    children=[
                                        html.Div(
                                            className="footer-item",
                                            children=[
                                                html.P(
                                                    className="theme-version",
                                                    children=[
                                                        "Built with the",
                                                        html.A(
                                                            children=[
                                                                "PyData Sphinx Theme"
                                                            ]
                                                        ),
                                                    ],
                                                )
                                            ],
                                        )
                                    ],
                                ),
                            ],
                        )
                    ],
                ),
            ]
        ),
    ]
)

