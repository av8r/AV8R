# -*- coding: utf-8 -*-
from io import StringIO
from ansi2html import Ansi2HTMLConverter
import dash_dangerously_set_inner_html


from dash import html, dcc, ctx
import dash_bootstrap_components as dbc
from dash_extensions import DeferScript
from dash_spa import config, callback, register_page, current_app
from dash_spa.logging import log
from flask import send_from_directory
from dash.dependencies import Input, Output
import json
import os

from dash_sphinx import SPHINX_DOC_ROOT, SPHINX_STATIC, SPHINX_DOC_ROUTE, SPHINX_INI_PREFIX, SPHINX_DOC_TITLE
# from dash_spa import add_external_scripts, add_external_stylesheets


import re
from urllib.parse import urlparse

_ADD_EXTERNALS = {
    'css': [
        '_static/styles/theme.css',     # ?digest=e353d410970836974a52',
        '_static/styles/pydata-sphinx-theme.css',    # ?digest=e353d410970836974a52',
        '_static/pygments.css',
    ],
    'js': [
        '_static/dash_documentation_options.js',
        '_static/scripts/pydata-sphinx-theme.js',
        '_static/doctools.js',
        '_static/sphinx_highlight.js',
    ]
}


class SphinxPage(object):
    doc_name = page_name = sphinx_doc_root = fjson_file = None
    fjson = None

    def __init__(self, **kwargs):
        log.debug(kwargs)
        # Setup with config_name
        if 'config_name' in kwargs:
            self.doc_name = kwargs['config_name']
            sphinx_opt = config.get(f"{SPHINX_INI_PREFIX}{self.doc_name}")
            [setattr(self, k, v) for k, v in sphinx_opt.__dict__.items()]

        # update/init with key=value arguments
        [setattr(self, k, v) for k, v in kwargs.items()]

        # DEBUG -- xxx images , others ...
        if self.doc_name:
            self.sphinx_doc_root = os.path.join(SPHINX_DOC_ROOT, self.doc_name)
        if self.page_name:
            _page_dir = os.path.join(SPHINX_DOC_ROOT, self.page_name)
            if os.path.isdir(_page_dir):
                self.page_name = os.path.join(self.page_name, 'index')
        else:
            self.page_name = 'index'

        # DEBUG -- xxx images , others ...
        if not self.page_name.endswith('.fjson'):
            self.page_name += '.fjson'
        self.fjson_file = os.path.join(self.sphinx_doc_root, self.page_name)
        if os.path.isfile(self.fjson_file):
            with open(self.fjson_file, 'r') as fjson:
                self.fjson = json.load(fjson)

        log.debug(self.fjson)

    def get_json_attr(self, name, default):
        def transform_url(match_obj):
            # (href|src)=("|')(uri)
            tag = match_obj.group(1)    # href | src
            quote = match_obj.group(2)  # double or simple quote
            if tag is not None:
                uri = match_obj.group(3)
                parsed_uri = urlparse(uri)
                # log.debug(parsed_uri)
                if parsed_uri.scheme:   # not empty -> return "as is"
                    return match_obj.group()
                else:
                    if tag == 'href':   # prefix uri with PRJ_name
                        return f"{tag}={quote}{self.doc_name}/{uri}"
                    else:   # relative to "sphinx route" served by flask (send_from_directory)
                        return f"{tag}={quote}{SPHINX_STATIC}/{self.doc_name}/{uri.replace('../', '')}"

        # ret. self.fjson[name].replace('href="', f'href="{self.doc_name}/') if name in self.fjson else default or None
        re_pattern = r'(href|src)=([\'"])?([^\'" >]+)'
        return re.sub(re_pattern, transform_url, self.fjson[name]) if name in self.fjson else default or None


def layout(sphinx_doc=None):
    log.debug(sphinx_doc)
    sphinx_element = sphinx_doc.split('/', 1) if sphinx_doc else [None]

    # XXX move to SphinxPage ?
    if not sphinx_element[0]:
        return html.Div(
            html.H1("No doc!")
        )

    sphinx_page = SphinxPage(
        config_name=sphinx_element[0],
        page_name=sphinx_element[1] if len(sphinx_element) > 1 else None
    )

    if sphinx_page.fjson is None:
        return html.Div(
            html.H1("No doc!")
        )

    # dbc.Container className="bd-container"
    # ... dbc.Switch ==> KO

    # return html.Div([
    #     html.Article(
    #         className="bd-article",
    #         children=dash_dangerously_set_inner_html.DangerouslySetInnerHTML(
    #             sphinx_page.get_json_attr('body', '')
    #         ),
    #     ),
    # ])

    # XXX DeferScript(  # DOCUMENTATION_OPTIONS.pagename fjson :   "current_page_name": "section_01/1_rst-cheatsheet",

    return dbc.Container(
        className="dash_sphinx bd-container",
        children=[
            html.Div([
                DeferScript(src=f"{SPHINX_STATIC}/{sphinx_element[0]}/{js}") for js in _ADD_EXTERNALS['js']
            ]),
            html.Div(
                className="bd-container__inner bd-page-width",
                children=[
                    html.Div(
                        className="bd-sidebar-primary bd-sidebar hide-on-wide",
                        children=[
                            html.Div(
                                className="sidebar-header-items sidebar-primary__section",
                                children=[
                                    html.Div(
                                        className="sidebar-header-items__center",
                                        children=[
                                            dbc.Navbar(
                                                className="navbar-item",
                                                children=[
                                                    dbc.Nav(
                                                        className="navbar-nav",
                                                        children=[
                                                            html.P(
                                                                className="sidebar-header-items__title",
                                                                children=[
                                                                    "Site Navigation"
                                                                ],
                                                            ),
                                                            dbc.Nav(
                                                                className="bd-navbar-elements navbar-nav",
                                                                children=[],
                                                            ),
                                                        ],
                                                    )
                                                ],
                                            )
                                        ],
                                    ),
                                    html.Div(
                                        className="sidebar-header-items__end",
                                        children=[
                                            dbc.Navbar(
                                                className="navbar-item",
                                                children=[],
                                            )
                                        ],
                                    ),
                                ],
                            ),
                            html.Div(
                                className="sidebar-primary-items__end sidebar-primary__section",
                                children=[],
                            ),
                            html.Div(
                                id="rtd-footer-container", children=[]
                            ),
                        ],
                    ),
                    html.Div(
                        className="bd-content",
                        children=[
                            dbc.Container(
                                className="bd-article-container",
                                children=[
                                    html.Div(
                                        className="bd-header-article",
                                        children=[],
                                    ),
                                    html.Div(id="searchbox", children=[]),
                                    html.Article(
                                        className="bd-article",
                                        children=dash_dangerously_set_inner_html.DangerouslySetInnerHTML(
                                            sphinx_page.get_json_attr('body', '')
                                        )
                                    ),
                                    html.Footer(
                                        className="bd-footer-article",
                                        children=[
                                            html.Div(
                                                className="footer-article-items footer-article__inner",
                                                children=[
                                                    html.Div(
                                                        className="footer-article-item",
                                                        children=[
                                                            html.Div(
                                                                className="prev-next-area",
                                                                children=[],
                                                            )
                                                        ],
                                                    )
                                                ],
                                            )
                                        ],
                                    ),
                                ],
                            ),
                            html.Div(
                                className="bd-sidebar-secondary bd-toc",
                                children=[
                                    html.Div(
                                        className="sidebar-secondary-items sidebar-secondary__inner",
                                        children=[
                                            html.Div(
                                                className="sidebar-secondary-item",
                                                children=[
                                                    html.Div(
                                                        className="page-toc tocsection onthispage",
                                                        children=[
                                                            html.I(
                                                                className="fa-solid fa-list",
                                                                # XXX YYY
                                                                children="On this page",
                                                            )
                                                        ],
                                                    ),
                                                    dbc.Nav(
                                                        className="bd-toc-nav page-toc",
                                                        children=[
                                                            html.Ul(
                                                                className="visible nav section-nav flex-column",
                                                                children=[
                                                                    html.Li(
                                                                        className="toc-h1 nav-item toc-entry",
                                                                        children=[
                                                                            # XXX - fix href ?
                                                                            # dcc.Link(
                                                                            #     className="reference internal nav-link",
                                                                            #     children=[
                                                                            #         "Welcome to demo’s documentation!"
                                                                            #     ],
                                                                            # )
                                                                        ],
                                                                    ),
                                                                    html.Li(
                                                                        className="toc-h1 nav-item toc-entry",
                                                                        children=[
                                                                            # XXX - fix href ?
                                                                            # dcc.Link(
                                                                            #     className="reference internal nav-link",
                                                                            #     children=[
                                                                            #         "Indices and tables"
                                                                            #     ],
                                                                            # )
                                                                        ],
                                                                    ),
                                                                ],
                                                            )
                                                        ],
                                                    ),
                                                ],
                                            ),
                                            html.Div(
                                                className="sidebar-secondary-item",
                                                children=[
                                                    html.Div(
                                                        className="tocsection sourcelink",
                                                        children=[
                                                            html.A(
                                                                children=[
                                                                    html.I(
                                                                        className="fa-solid fa-file-lines",
                                                                        children=[],
                                                                    )
                                                                ]
                                                            )
                                                        ],
                                                    )
                                                ],
                                            ),
                                        ],
                                    )
                                ],
                            ),
                        ],
                    ),
                    html.Footer(className="bd-footer-content", children=[]),
                ],
            )
        ],
    ),


register_page(__name__,
              path=f"{SPHINX_DOC_ROUTE}",
              path_template=f"{SPHINX_DOC_ROUTE}/<sphinx_doc>",
              title=SPHINX_DOC_TITLE,
              short_name='Sphinx',
              layout=layout)


@current_app.server.route(f'{SPHINX_STATIC}/<path:sub_path>')
def sphinx_route(sub_path):
    log.info(f'sphinx_route: {SPHINX_DOC_ROOT} {sub_path}')
    if sub_path.endswith('/dash_documentation_options.js'):
        path_element = sub_path.split('/', 1)
        _url_root_ = f"{SPHINX_STATIC}/{path_element[0]}"
        # _page_name_ = 'index'   # XXX fjson :   "current_page_name": "section_01/1_rst-cheatsheet",
        _add_css_ = '\n'.join(
            [f"loadStyle('{SPHINX_STATIC}/{path_element[0]}/{css}');" for css in _ADD_EXTERNALS['css']]
        )
        return """
var DOCUMENTATION_OPTIONS = {
    URL_ROOT: '@URL_ROOT@',
    VERSION: '',
    LANGUAGE: 'en',
    COLLAPSE_INDEX: false,
    BUILDER: 'jsontoc',
    FILE_SUFFIX: '.fjson',
    LINK_SUFFIX: '.fjson',
    HAS_SOURCE: true,
    SOURCELINK_SUFFIX: '.txt',
    NAVIGATION_WITH_KEYS: true,
    SHOW_SEARCH_SUMMARY: true,
    ENABLE_SEARCH_SHORTCUTS: true,
    // pagename: '@PAGE_NAME@',
};

<!-- script data-cfasync="false" -->
    document.documentElement.dataset.mode = "dark";
    document.documentElement.dataset.theme = "dark";
<!-- /script -->

function loadStyle(href, callback){
    // avoid duplicates
    for(var i = 0; i < document.styleSheets.length; i++){
        if(document.styleSheets[i].href == href){
            return;
        }
    }
    var head  = document.getElementsByTagName('head')[0];
    var link  = document.createElement('link');
    link.rel  = 'stylesheet';
    link.type = 'text/css';
    link.href = href;
    if (callback) { link.onload = function() { callback() } }
    head.appendChild(link);
}
// debugger;
@ADD_CSS@
        """\
            .replace('@URL_ROOT@', _url_root_)\
            .replace('@PAGE_NAME@', _page_name_)\
            .replace('@ADD_CSS@', _add_css_)

    return send_from_directory(SPHINX_DOC_ROOT, sub_path)
