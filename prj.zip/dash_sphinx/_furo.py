html.HTML(
    className="no-js",
    children=[
        html.HEAD(children=[html.Title(children=["demo demo documentation"])]),
        html.BODY(
            children=[
                html.SVG(
                    children=[
                        html.Title(children=["Contents"]),
                        html.SVG(children=[]),
                        html.Title(children=["Menu"]),
                        html.SVG(className="feather-menu", children=[]),
                        html.Title(children=["Expand"]),
                        html.SVG(className="feather-chevron-right", children=[]),
                        html.Title(children=["Light mode"]),
                        html.SVG(className="feather-sun", children=[]),
                        html.Title(children=["Dark mode"]),
                        html.SVG(className="icon-tabler-moon", children=[]),
                        html.Title(children=["Auto light/dark mode"]),
                        html.Shadow(className="icon-tabler-shadow", children=[]),
                    ]
                ),
                dbc.Label(
                    className="overlay sidebar-overlay",
                    children=[
                        html.Div(
                            className="visually-hidden",
                            children=["Hide navigation sidebar"],
                        )
                    ],
                ),
                dbc.Label(
                    className="overlay toc-overlay",
                    children=[
                        html.Div(
                            className="visually-hidden",
                            children=["Hide table of contents sidebar"],
                        )
                    ],
                ),
                html.Div(
                    className="page",
                    children=[
                        html.Header(
                            className="mobile-header",
                            children=[
                                html.Div(
                                    className="header-left",
                                    children=[
                                        dbc.Label(
                                            className="nav-overlay-icon",
                                            children=[
                                                html.Div(
                                                    className="visually-hidden",
                                                    children=[
                                                        "Toggle site navigation sidebar"
                                                    ],
                                                ),
                                                html.I(
                                                    className="icon",
                                                    children=[html.SVG(children=[])],
                                                ),
                                            ],
                                        )
                                    ],
                                ),
                                html.Div(
                                    className="header-center",
                                    children=[
                                        html.A(
                                            children=[
                                                html.Div(
                                                    className="brand",
                                                    children=[
                                                        "demo demo documentation"
                                                    ],
                                                )
                                            ]
                                        )
                                    ],
                                ),
                                html.Div(
                                    className="header-right",
                                    children=[
                                        html.Div(
                                            className="theme-toggle-container theme-toggle-header",
                                            children=[],
                                        ),
                                        dbc.Label(
                                            className="toc-overlay-icon toc-header-icon no-toc",
                                            children=[
                                                html.Div(
                                                    className="visually-hidden",
                                                    children=[
                                                        "Toggle table of contents sidebar"
                                                    ],
                                                ),
                                                html.I(
                                                    className="icon",
                                                    children=[html.SVG(children=[])],
                                                ),
                                            ],
                                        ),
                                    ],
                                ),
                            ],
                        ),
                        html.Aside(
                            className="sidebar-drawer",
                            children=[
                                dbc.Container(
                                    className="sidebar-container",
                                    children=[
                                        html.Div(
                                            className="sidebar-sticky",
                                            children=[
                                                html.A(
                                                    className="sidebar-brand",
                                                    children=[
                                                        html.Span(
                                                            className="sidebar-brand-text",
                                                            children=[
                                                                "demo demo documentation"
                                                            ],
                                                        )
                                                    ],
                                                ),
                                                html.Div(id="searchbox", children=[]),
                                                html.Div(
                                                    className="sidebar-scroll",
                                                    children=[
                                                        html.Div(
                                                            className="sidebar-tree",
                                                            children=[],
                                                        )
                                                    ],
                                                ),
                                            ],
                                        )
                                    ],
                                )
                            ],
                        ),
                        html.Div(
                            className="main",
                            children=[
                                html.Div(
                                    className="content",
                                    children=[
                                        dbc.Container(
                                            className="article-container",
                                            children=[
                                                dcc.Link(
                                                    className="back-to-top muted-link",
                                                    children=[
                                                        html.SVG(children=[]),
                                                        html.Span(
                                                            children=["Back to top"]
                                                        ),
                                                    ],
                                                ),
                                                dbc.Container(
                                                    className="content-icon-container",
                                                    children=[
                                                        html.Div(
                                                            className="theme-toggle-container theme-toggle-content",
                                                            children=[],
                                                        ),
                                                        dbc.Label(
                                                            className="toc-overlay-icon toc-content-icon no-toc",
                                                            children=[
                                                                html.Div(
                                                                    className="visually-hidden",
                                                                    children=[
                                                                        "Toggle table of contents sidebar"
                                                                    ],
                                                                ),
                                                                html.I(
                                                                    className="icon",
                                                                    children=[
                                                                        html.SVG(
                                                                            children=[]
                                                                        )
                                                                    ],
                                                                ),
                                                            ],
                                                        ),
                                                    ],
                                                ),
                                                html.Article(
                                                    children=[
                                                        html.Section(
                                                            id="welcome-to-demo-s-documentation",
                                                            children=[
                                                                html.H1(
                                                                    children=[
                                                                        "Welcome to demo’s documentation!",
                                                                        html.A(
                                                                            className="headerlink",
                                                                            children=[
                                                                                "#"
                                                                            ],
                                                                        ),
                                                                    ]
                                                                ),
                                                                html.Div(
                                                                    className="toctree-wrapper compound",
                                                                    children=[],
                                                                ),
                                                            ],
                                                        ),
                                                        html.Section(
                                                            id="indices-and-tables",
                                                            children=[
                                                                html.H1(
                                                                    children=[
                                                                        "Indices and tables",
                                                                        html.A(
                                                                            className="headerlink",
                                                                            children=[
                                                                                "#"
                                                                            ],
                                                                        ),
                                                                    ]
                                                                ),
                                                                html.Ul(
                                                                    className="simple",
                                                                    children=[
                                                                        html.Li(
                                                                            children=[
                                                                                html.P(
                                                                                    children=[
                                                                                        html.A(
                                                                                            className="reference internal",
                                                                                            children=[
                                                                                                html.Span(
                                                                                                    className="std std-ref",
                                                                                                    children=[
                                                                                                        "Index"
                                                                                                    ],
                                                                                                )
                                                                                            ],
                                                                                        )
                                                                                    ]
                                                                                )
                                                                            ]
                                                                        ),
                                                                        html.Li(
                                                                            children=[
                                                                                html.P(
                                                                                    children=[
                                                                                        html.A(
                                                                                            className="reference internal",
                                                                                            children=[
                                                                                                html.Span(
                                                                                                    className="std std-ref",
                                                                                                    children=[
                                                                                                        "Module Index"
                                                                                                    ],
                                                                                                )
                                                                                            ],
                                                                                        )
                                                                                    ]
                                                                                )
                                                                            ]
                                                                        ),
                                                                        html.Li(
                                                                            children=[
                                                                                html.P(
                                                                                    children=[
                                                                                        html.A(
                                                                                            className="reference internal",
                                                                                            children=[
                                                                                                html.Span(
                                                                                                    className="std std-ref",
                                                                                                    children=[
                                                                                                        "Search Page"
                                                                                                    ],
                                                                                                )
                                                                                            ],
                                                                                        )
                                                                                    ]
                                                                                )
                                                                            ]
                                                                        ),
                                                                    ],
                                                                ),
                                                            ],
                                                        ),
                                                    ]
                                                ),
                                            ],
                                        ),
                                        html.Footer(
                                            children=[
                                                html.Div(
                                                    className="related-pages",
                                                    children=[],
                                                ),
                                                html.Div(
                                                    className="bottom-of-page",
                                                    children=[
                                                        html.Div(
                                                            className="left-details",
                                                            children=[
                                                                html.Div(
                                                                    className="copyright",
                                                                    children=[
                                                                        "Copyright © 2023, steph"
                                                                    ],
                                                                ),
                                                                html.A(
                                                                    children=["Sphinx"]
                                                                ),
                                                                dcc.Link(
                                                                    className="muted-link",
                                                                    children=[
                                                                        "@pradyunsg"
                                                                    ],
                                                                ),
                                                                html.A(
                                                                    children=["Furo"]
                                                                ),
                                                            ],
                                                        ),
                                                        html.Div(
                                                            className="right-details",
                                                            children=[],
                                                        ),
                                                    ],
                                                ),
                                            ]
                                        ),
                                    ],
                                ),
                                html.Aside(className="toc-drawer no-toc", children=[]),
                            ],
                        ),
                    ],
                ),
            ]
        ),
    ],
)

