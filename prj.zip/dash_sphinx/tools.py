# -*- coding: utf-8 -*-

from dash_spa.logging import log


def get_json_response(view_name, *args, **kwargs):
    from flask import current_app
    import json
    from collections import OrderedDict

    '''Calls internal view method, parse json, and return python dict.'''

    # TODO: to fix ! default API path / version ....
    view_name = view_name.replece('api_page', 'api_v1')
    try:
        view = current_app.view_functions[view_name]
        res = view(*args, **kwargs)
        # XXX: ...
        js = json.loads(res.data, object_pairs_hook=OrderedDict)
        return js
    except KeyError as e:
        log.error(f"get_json_response({view_name}, {args}, {kwargs}): {e}")
        return {}


def get_api_json_response(page, *args, **kwargs):
    """ call blueprint_route, argumument=value, ..."""
    from flask import current_app as app
    with app.test_request_context():
        app.logger.debug(f"get_api_json_response: {page} / {args} / {kwargs}")
        return get_json_response(page, *args, **kwargs)
