"""dash-sphinx - Dash Pages SPA Framework"""

from ._version import __version__
from ensurepip import version

import os

# TODO: via conf
SPHINX_DOC_ROOT = os.path.join(os.environ['DASH_SPA_CWD'], 'app', 'templates', 'sphinxdoc')

SPHINX_STATIC = '/sphinx_static'
SPHINX_DOC_ROUTE = '/sphinxdoc'
SPHINX_ADMIN_ROUTE = '/admin/sphinx'

SPHINX_INI_PREFIX = 'sphinx.'

SPHINX_DOC_TITLE = 'Sphinx Documentation'